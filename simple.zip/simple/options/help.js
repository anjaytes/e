exports.listmenu = (prefix) => {
return` 𝗠𝗔𝗜𝗡 𝗠𝗘𝗡𝗨
 ● ${prefix}owner
 ● ${prefix}script
 ● ${prefix}toimg
 ● ${prefix}sticker
 ● ${prefix}spamcall
 ● ${prefix}jadibot
 ● ${prefix}listjadibot
 ● ${prefix}infoupdate
 ● ${prefix}groupbot
 
 𝗔𝗡𝗢𝗡𝗬𝗠𝗢𝗨𝗦 𝗖𝗛𝗔𝗧
 ● ${prefix}chat
 ● ${prefix}skip
 ● ${prefix}start
 ● ${prefix}secret
 ● ${prefix}confess
 ● ${prefix}menfess
 ● ${prefix}secretchat
 ● ${prefix}stopchat

 𝗢𝗪𝗡𝗘𝗥 𝗠𝗘𝗡𝗨
 ● ${prefix}error
 ● ${prefix}infouser
 ● ${prefix}runtime
 ● ${prefix}session
 ● ${prefix}resetdb
 ● ${prefix}addprem
 ● ${prefix}delprem
 ● ${prefix}broadcast
 ● ${prefix}dashboard

 𝗚𝗥𝗢𝗨𝗣 𝗠𝗘𝗡𝗨
 ● ${prefix}hidetag
 ● ${prefix}tagall
 ● ${prefix}fitnah
 ● ${prefix}delete
 ● ${prefix}revoke
 ● ${prefix}linkgrup
 ● ${prefix}setdesc
 ● ${prefix}demote
 ● ${prefix}antilink
 ● ${prefix}promote
 ● ${prefix}setppgrup
 ● ${prefix}kick @tag
 ● ${prefix}setnamegc
 ● ${prefix}group open
 ● ${prefix}group close

 𝗦𝗧𝗔𝗟𝗞𝗘𝗥 𝗠𝗘𝗡𝗨
 ● ${prefix}ffstalk *id*
 ● ${prefix}mlstalk *id|zone*
 ● ${prefix}npmstalk *packname*
 ● ${prefix}githubstalk *username*

 𝗞𝗔𝗟𝗞𝗨𝗟𝗔𝗧𝗢𝗥
 ● ${prefix}kali *angka angka*
 ● ${prefix}bagi *angka angka*
 ● ${prefix}kurang *angka angka*
 ● ${prefix}tambah *angka angka*

 𝗦𝗧𝗢𝗥𝗘 𝗠𝗘𝗡𝗨
 ● ${prefix}list *<only grup>*
 ● ${prefix}addlist *key@pesan*
 ● ${prefix}dellist *<options>*
 ● ${prefix}update *key@pesan*
 ● ${prefix}proses *<reply orderan>*
 ● ${prefix}done *<reply orderan>*`
}